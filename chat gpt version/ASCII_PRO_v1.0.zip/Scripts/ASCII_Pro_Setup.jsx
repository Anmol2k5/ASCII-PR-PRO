
app.beginUndoGroup("Create ASCII Pro");

var comp = app.project.activeItem;
if (!(comp instanceof CompItem)) {
  alert("Please select a composition.");
  app.endUndoGroup();
  return;
}

var src = null;
for (var i = 1; i <= comp.numLayers; i++) {
  if (comp.layer(i).name === "SOURCE") {
    src = comp.layer(i);
    break;
  }
}

if (!src) {
  alert("Please rename your footage layer to 'SOURCE'");
  app.endUndoGroup();
  return;
}

var ctrl = comp.layers.addNull();
ctrl.name = "ASCII_CONTROLS";

function addSlider(name, value) {
  var s = ctrl.Effects.addProperty("ADBE Slider Control");
  s.name = name;
  s.property("Slider").setValue(value);
}

function addCheckbox(name, value) {
  var c = ctrl.Effects.addProperty("ADBE Checkbox Control");
  c.name = name;
  c.property("Checkbox").setValue(value);
}

addSlider("Character Density", 14);
addSlider("ASCII Set", 1);
addCheckbox("Invert", 0);

var txt = comp.layers.addText("@");
txt.name = "ASCII_TEXT";
txt.property("Transform").property("Position").setValue([comp.width/2, comp.height/2]);

alert("ASCII Pro setup complete!");
app.endUndoGroup();
