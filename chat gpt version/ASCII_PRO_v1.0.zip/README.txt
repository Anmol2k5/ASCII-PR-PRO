
ASCII PRO – Installation Guide

1. Copy ASCII_Pro_Setup.jsx to:
   After Effects / Support Files / Scripts

2. Restart After Effects

3. Import your footage and rename it to:
   SOURCE

4. Run:
   File → Scripts → ASCII_Pro_Setup

5. Paste the provided expression into:
   ASCII_TEXT → Source Text

NOTE:
The .ffx preset must be created inside After Effects by saving the animated properties.
